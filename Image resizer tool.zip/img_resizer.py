import os
from PIL import Image

# Define input and output folders
input_folder = 'images'
output_folder = 'resized'

# Desired size (width, height)
target_size = (800, 600)

# Create output folder if it doesn't exist
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Loop through all files in the input folder
for filename in os.listdir(input_folder):
    if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
        # Full path to the image
        input_path = os.path.join(input_folder, filename)

        # Open the image
        with Image.open(input_path) as img:
            # Resize the image
            resized_img = img.resize(target_size)

            # Optional: Convert to JPEG format
            output_filename = os.path.splitext(filename)[0] + '.jpg'
            output_path = os.path.join(output_folder, output_filename)

            # Save resized image
            resized_img.save(output_path, 'JPEG')

            print(f'Resized and saved: {output_filename}')
